from .fastpitch import generate_vocab_mapping

patches = {"FastPitchModel": [generate_vocab_mapping]}
